class_name EnemyShot
extends Area2D
var direction := Vector2.DOWN
var speed := 250.0
var damage := 1
var _life := 4.0
var _sprite: Sprite2D
func _ready() -> void:
 add_to_group("enemy_shots")
 collision_layer = 32
 collision_mask = 3
 var shape := CollisionShape2D.new()
 var circle := CircleShape2D.new()
 circle.radius = 9
 shape.shape = circle
 add_child(shape)
 _sprite = Sprite2D.new()
 _sprite.texture = preload("res://assets/bullet_laser.svg")
 _sprite.scale = Vector2(0.12,0.12)
 _sprite.rotation = direction.angle()+PI/2
 add_child(_sprite)
 body_entered.connect(_impact)
func _physics_process(delta: float) -> void:
 if not Game.is_running: return
 position += direction*speed*delta
 _life -= delta
 if _life<=0: queue_free()
func _impact(body: Node2D) -> void:
 if body is Player: body.receive_hit(damage)
 queue_free()
