extends Control
func _ready() -> void:
 Game.is_running = false
 var bg := ArcadeUI.image("res://assets/future_updates/hangar/hangar_space_background.svg", Vector2.ZERO)
 bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 # Keep all portrait artwork; the surrounding cosmic color extends the canvas.
 var fill := ColorRect.new()
 fill.color = Color("050716")
 fill.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 add_child(fill)
 add_child(bg)
 var center := CenterContainer.new()
 center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 add_child(center)
 var panel := PanelContainer.new()
 panel.add_theme_stylebox_override("panel", ArcadeUI.surface())
 center.add_child(panel)
 var box := VBoxContainer.new()
 box.add_theme_constant_override("separation", 18)
 panel.add_child(box)
 box.add_child(ArcadeUI.image("res://assets/future_updates/aircraft/player_saucer.svg", Vector2(490, 145)))
 var title := ArcadeUI.label("ARENA DASH", 38, Color("ffd166"))
 title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
 box.add_child(title)
 var subtitle := ArcadeUI.label("12 AIRCRAFT  •  8 WORLDS  •  ONE CAMPAIGN", 18)
 subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
 box.add_child(subtitle)
 for item in [["ENTER HANGAR", "button_play", "res://scenes/hangar.tscn"], ["PLANET CAMPAIGN", "button_menu", "res://scenes/level_select.tscn"]]:
  var btn := ArcadeUI.button(item[0], item[1])
  btn.pressed.connect(func() -> void: get_tree().change_scene_to_file(item[2]))
  box.add_child(btn)
 var settings := ArcadeUI.button("SETTINGS", "button_settings")
 settings.pressed.connect(func() -> void: ArcadeUI.settings(self))
 box.add_child(settings)
func _unhandled_input(event: InputEvent) -> void:
 if event is InputEventKey and event.pressed and event.keycode == KEY_ENTER:
  get_tree().change_scene_to_file("res://scenes/hangar.tscn")
