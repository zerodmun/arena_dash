class_name ArcadeUI
extends RefCounted
const KIT := "res://assets/future_updates/ui/"
static func surface() -> StyleBoxFlat:
 var s := StyleBoxFlat.new()
 s.bg_color = Color("101d38", 0.95)
 s.border_color = Color("3b7097")
 s.set_border_width_all(2)
 s.set_corner_radius_all(20)
 s.content_margin_left = 24
 s.content_margin_right = 24
 s.content_margin_top = 20
 s.content_margin_bottom = 20
 return s
static func label(text: String, font_size := 24, color := Color.WHITE) -> Label:
 var l := Label.new()
 l.text = text
 l.add_theme_font_size_override("font_size", font_size)
 l.add_theme_color_override("font_color", color)
 l.mouse_filter = Control.MOUSE_FILTER_IGNORE
 return l
static func image(path: String, minimum: Vector2) -> TextureRect:
 var t := TextureRect.new()
 t.texture = load(path)
 t.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
 t.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_CENTERED
 t.custom_minimum_size = minimum
 t.mouse_filter = Control.MOUSE_FILTER_IGNORE
 return t
static func icon(button: Button, asset: String) -> void:
 button.icon = load(KIT + asset + ".svg")
 button.expand_icon = true
 button.add_theme_constant_override("icon_max_width", 40)
static func button(text: String, asset := "") -> Button:
 var b := Button.new()
 b.text = text
 b.custom_minimum_size = Vector2(0, 62)
 b.add_theme_font_size_override("font_size", 22)
 for state in ["normal", "hover", "pressed", "disabled", "focus"]:
  var s := surface()
  if state == "hover": s.bg_color = Color("234569")
  if state == "pressed": s.bg_color = Color("31618b")
  if state == "focus": s.bg_color = Color.TRANSPARENT; s.border_color = Color("ffd166")
  if state == "disabled": s.bg_color = Color("182031"); s.border_color = Color("29364a")
  b.add_theme_stylebox_override(state, s)
 if not asset.is_empty(): icon(b, asset)
 return b
static func settings(parent: Node) -> void:
 var dialog := AcceptDialog.new()
 dialog.title = "FLIGHT SETTINGS"
 dialog.min_size = Vector2i(450, 260)
 var box := VBoxContainer.new()
 dialog.add_child(box)
 var audio := CheckButton.new()
 audio.text = "SOUND EFFECTS"
 audio.button_pressed = Game.audio_enabled
 audio.toggled.connect(func(value: bool) -> void: Game.audio_enabled = value; Game.save_settings())
 box.add_child(audio)
 var motion := CheckButton.new()
 motion.text = "REDUCE CAMERA SHAKE"
 motion.button_pressed = Game.reduced_motion
 motion.toggled.connect(func(value: bool) -> void: Game.reduced_motion = value; Game.save_settings())
 box.add_child(motion)
 box.add_child(label("WASD / arrows: fly   •   Space / J: fire\nEsc / P: pause   •   F11: fullscreen", 16))
 parent.add_child(dialog)
 dialog.confirmed.connect(dialog.queue_free)
 dialog.canceled.connect(dialog.queue_free)
 dialog.popup_centered()
