class_name FlightDialog
extends CanvasLayer
## In-canvas landscape dialog: blocks underlying input, retains pause and restores focus.
var mode := "settings"
var panel: PanelContainer
var audio: Button
var motion: Button
var close_button: Button
var _was_paused := false
var _focus: Control
var _root: Control
func _ready() -> void:
 name="FlightDialog"
 layer=100
 process_mode=Node.PROCESS_MODE_ALWAYS
 _was_paused=get_tree().paused
 _focus=get_viewport().gui_get_focus_owner()
 if Game.is_running:
  get_tree().paused=true
  Input.action_release("fire")
  for stick in get_tree().get_nodes_in_group("joystick"): stick._reset()
 _root=Control.new()
 _root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 add_child(_root)
 var dim:=ColorRect.new()
 dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 dim.color=Color(0.025,0.015,0.09,0.82)
 _root.add_child(dim)
 panel=PanelContainer.new()
 panel.add_theme_stylebox_override("panel",ArcadeUI.surface(24))
 _root.add_child(panel)
 var box:=VBoxContainer.new()
 box.add_theme_constant_override("separation",20)
 panel.add_child(box)
 var heading:=HBoxContainer.new()
 box.add_child(heading)
 var title:=ArcadeUI.label("FLIGHT SETTINGS" if mode=="settings" else "FLIGHT MANUAL",30,ArcadeUI.GOLD)
 title.size_flags_horizontal=Control.SIZE_EXPAND_FILL
 heading.add_child(title)
 close_button=ArcadeUI.button("","button_close")
 close_button.custom_minimum_size=Vector2(64,64)
 close_button.tooltip_text="Close (Escape)"
 close_button.pressed.connect(close)
 heading.add_child(close_button)
 var columns:=HBoxContainer.new()
 columns.add_theme_constant_override("separation",32)
 columns.size_flags_vertical=Control.SIZE_EXPAND_FILL
 box.add_child(columns)
 var controls:=VBoxContainer.new()
 controls.custom_minimum_size.x=340
 controls.add_theme_constant_override("separation",16)
 columns.add_child(controls)
 if mode=="settings":
  audio=ArcadeUI.button("","button_audio")
  motion=ArcadeUI.button("")
  controls.add_child(audio)
  controls.add_child(motion)
  audio.pressed.connect(func() -> void: Game.audio_enabled=not Game.audio_enabled; Game.save_settings(); _refresh())
  motion.pressed.connect(func() -> void: Game.reduced_motion=not Game.reduced_motion; Game.save_settings(); _refresh())
  controls.add_child(ArcadeUI.label("Changes are saved automatically.",16,ArcadeUI.MUTED))
  _refresh()
 else:
  controls.add_child(ArcadeUI.image(Game.get_current_ship().texture,Vector2(300,190)))
  controls.add_child(ArcadeUI.label("%s  /  %s" % [Game.get_current_ship().name,Game.get_current_ship()["class"]],16,ArcadeUI.CYAN))
 var manual:=ArcadeUI.label("HANGAR\nArrows / A–D or swipe: select aircraft\nLoadout: choose weapon • Enter: deploy\nPlanet button: inspect campaign\n\nFLIGHT\nWASD / arrows: fly • Space / J: fire\nEsc / P: pause • F11: fullscreen\nTouch: left joystick + right fire button",18,ArcadeUI.MUTED)
 manual.autowrap_mode=TextServer.AUTOWRAP_WORD_SMART
 manual.size_flags_horizontal=Control.SIZE_EXPAND_FILL
 columns.add_child(manual)
 get_viewport().size_changed.connect(_layout)
 _layout()
 var buttons: Array[Button]=[close_button]
 if mode=="settings": buttons.append(audio); buttons.append(motion)
 ArcadeUI.focus_loop(buttons)
 for frame in 2: await get_tree().process_frame
 _layout()
 close_button.grab_focus()
 if not Game.reduced_motion:
  panel.modulate.a=0
  create_tween().tween_property(panel,"modulate:a",1.0,0.16)
func _refresh() -> void:
 ArcadeUI.icon(audio,"button_audio" if Game.audio_enabled else "button_audio_off")
 audio.text="SOUND EFFECTS  /  " + ("ON" if Game.audio_enabled else "OFF")
 motion.text="REDUCED MOTION  /  " + ("ON" if Game.reduced_motion else "OFF")
 ArcadeUI.style_button(audio,false,Game.audio_enabled)
 ArcadeUI.style_button(motion,false,Game.reduced_motion)
func _layout() -> void:
 var vp:=get_viewport().get_visible_rect().size
 panel.size=Vector2(minf(vp.x-64,1000),minf(vp.y-64,450))
 panel.position=(vp-panel.size)*0.5
func close() -> void:
 get_tree().paused=_was_paused
 if is_instance_valid(_focus): _focus.grab_focus()
 queue_free()
func _input(event: InputEvent) -> void:
 if event is InputEventKey and event.pressed:
  if event.keycode==KEY_ESCAPE:
   close()
   get_viewport().set_input_as_handled()
  elif event.keycode in [KEY_ENTER,KEY_P,KEY_R,KEY_LEFT,KEY_RIGHT] and not (event.keycode==KEY_ENTER and get_viewport().gui_get_focus_owner() is Button):
   get_viewport().set_input_as_handled()
