class_name Campaign
extends RefCounted
## Stable level IDs follow the planet asset naming convention.
const ORDER := ["cyber", "forest", "space", "coast", "desert", "volcano", "glacier", "toxic"]
const PLANETS := ["cyber_matrix", "primal_jungle", "void_horizon", "coastal_front", "dune_outpost", "magma_caldera", "glacial_tundra", "toxic_citadel"]
const DIFFICULTY := ["CADET", "PATROL", "HOSTILE", "VETERAN", "ELITE", "INFERNO", "EXTREME", "COMMANDER"]
static func index(map_id: String) -> int:
 return maxi(0, ORDER.find(map_id))
static func planet(map_id: String) -> String:
 return "res://assets/future_updates/maps/planet_%s.svg" % PLANETS[index(map_id)]
static func target(map_id: String) -> int:
 return 16 + index(map_id) * 6
