class_name LevelSelect
extends Control
var cards: Dictionary = {}
func _ready() -> void:
 Game.is_running = false
 var background := ArcadeUI.image("res://assets/future_updates/maps/map_galaxy_spiral.svg", Vector2.ZERO)
 background.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 background.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
 add_child(background)
 var margin := MarginContainer.new()
 margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
 for edge in ["left", "right", "top", "bottom"]: margin.add_theme_constant_override("margin_" + edge, 32)
 add_child(margin)
 var column := VBoxContainer.new()
 column.add_theme_constant_override("separation", 24)
 margin.add_child(column)
 var top := HBoxContainer.new()
 column.add_child(top)
 var back := ArcadeUI.button("HANGAR", "button_back")
 back.pressed.connect(func() -> void: get_tree().change_scene_to_file("res://scenes/hangar.tscn"))
 top.add_child(back)
 var title := ArcadeUI.label("PLANET CAMPAIGN", 36, Color("ffd166"))
 title.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
 top.add_child(title)
 var settings := ArcadeUI.button("", "button_settings")
 settings.custom_minimum_size.x = 70
 settings.pressed.connect(func() -> void: ArcadeUI.settings(self))
 top.add_child(settings)
 var intro := ArcadeUI.label("Eight worlds. One flight path. Clear each mission to open the next orbit.", 20)
 intro.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 column.add_child(intro)
 var scroll := ScrollContainer.new()
 scroll.size_flags_vertical = Control.SIZE_EXPAND_FILL
 scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
 column.add_child(scroll)
 var grid := GridContainer.new()
 grid.size_flags_horizontal = Control.SIZE_EXPAND_FILL
 grid.add_theme_constant_override("h_separation", 18)
 grid.add_theme_constant_override("v_separation", 18)
 scroll.add_child(grid)
 resized.connect(func() -> void: grid.columns = 4 if size.x >= 1500 else (2 if size.x >= 850 else 1))
 grid.columns = 4 if get_viewport_rect().size.x >= 1500 else (2 if get_viewport_rect().size.x >= 850 else 1)
 for i in Campaign.ORDER.size():
  var id: String = Campaign.ORDER[i]
  var map: Dictionary = Game.MAPS[id]
  var unlocked := Game.is_level_unlocked(id)
  var card := ArcadeUI.button("")
  card.size_flags_horizontal = Control.SIZE_EXPAND_FILL
  card.custom_minimum_size = Vector2(320, 320)
  card.disabled = not unlocked
  card.tooltip_text = "Clear the previous planet to unlock" if not unlocked else "Select this planet and return to hangar"
  grid.add_child(card)
  cards[id] = card
  card.pressed.connect(func() -> void:
   if Game.select_level(id): get_tree().change_scene_to_file("res://scenes/hangar.tscn"))
  var content := VBoxContainer.new()
  content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
  content.offset_left = 16; content.offset_right = -16; content.offset_top = 12; content.offset_bottom = -12
  content.mouse_filter = Control.MOUSE_FILTER_IGNORE
  card.add_child(content)
  var heading := ArcadeUI.label("%02d  /  %s" % [i + 1, Campaign.DIFFICULTY[i]], 18, map.color)
  content.add_child(heading)
  var planet := ArcadeUI.image(Campaign.planet(id), Vector2(0, 124))
  if not unlocked: planet.modulate = Color(0.4, 0.4, 0.5)
  content.add_child(planet)
  content.add_child(ArcadeUI.label(map.name, 22))
  content.add_child(ArcadeUI.label("Eliminate %d drones" % Campaign.target(id), 16, Color("b5c9df")))
  var status := "LOCKED" if not unlocked else ("COMPLETED" if Game.completed_levels.has(id) else "READY TO DEPLOY")
  content.add_child(ArcadeUI.label(status, 16, Color("ffd166") if unlocked else Color("738397")))
  var stars := HBoxContainer.new()
  stars.mouse_filter = Control.MOUSE_FILTER_IGNORE
  content.add_child(stars)
  for star in 3:
   stars.add_child(ArcadeUI.image(ArcadeUI.KIT + ("badge_star_active.svg" if star < int(Game.completed_levels.get(id, 0)) else "badge_star_inactive.svg"), Vector2(28, 28)))
 var legend := ArcadeUI.label("Stars: mission cleared  /  finish with 2+ shields  /  finish within 150 seconds", 16, Color("b5c9df"))
 legend.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
 column.add_child(legend)
func _unhandled_input(event: InputEvent) -> void:
 if event is InputEventKey and event.pressed and event.keycode == KEY_ESCAPE:
  get_tree().change_scene_to_file("res://scenes/hangar.tscn")
