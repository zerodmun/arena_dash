# Arena Dash

A Godot 4.7 2D aircraft combat game with twelve selectable craft, four weapons, and an eight-world planetary campaign.

Open `project.godot` in Godot and run the project, or launch `godot --path .`. The main menu opens the hangar, campaign and settings. Clear each world's drone objective to unlock the next planet. Replay completed worlds to improve the saved three-star rating.

Desktop controls: WASD/arrows to fly, Space/J to fire, Esc/P to pause, F11 for fullscreen. In the hangar, A/D selects aircraft and Enter deploys. Mobile controls use the floating joystick and hold-to-fire button; the hangar supports swiping and scrolling.

Campaign order: Cyber Matrix → Primal Jungle → Void Horizon → Coastal Front → Dune Outpost → Magma Caldera → Glacial Tundra → Toxic Citadel. Each world has its own original map, matching planet art, extended 6,800 × 4,400 arena and increasing enemy speed, armor and population.

Run checks:

```sh
godot --headless --path . tests/game_smoke.tscn
godot --headless --path . tests/hangar_review.tscn
godot --path . --rendering-method gl_compatibility tests/hangar_review.tscn -- --screenshots
```

Build locally:

```sh
godot --headless --path . --export-release Web build/web/index.html
./build_apk.sh --export-release
python3 serve_web.py
```

The Web build is served at http://127.0.0.1:8060. Android retains the existing local signing configuration. No external hosting is required.

See `docs/OVERHAUL.md` for asset usage, landscape adaptation, progression rules, validation and limitations. `docs/asset-inventory.json` contains the complete recursive asset inventory. `overhaul-backup.zip` preserves the previous source/configuration.
